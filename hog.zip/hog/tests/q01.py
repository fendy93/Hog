test = {
  'names': [
    'q01',
    '1',
    'q1'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> roll_dice(2, make_test_dice(4, 6, 1))
        38086a887499ac2379964fcc3021b260
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> roll_dice(3, make_test_dice(4, 6, 1))
        1d33628009484489f555bc97b14d09a3
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> roll_dice(3, make_test_dice(1, 2, 3))
        1d33628009484489f555bc97b14d09a3
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> counted_dice = make_test_dice(4, 1, 2, 6)
        >>> roll_dice(3, counted_dice)
        1d33628009484489f555bc97b14d09a3
        # locked
        >>> roll_dice(1, counted_dice)  # Make sure you call dice exactly num_rolls times!
        19a95194687a0623f04d6826f5b1ea51
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}