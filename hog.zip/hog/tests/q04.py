test = {
  'names': [
    'q04',
    '4',
    'q4'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(1, 1, goal=100) # start can be 0 or 1
        >>> score0
        dd83f0f00a8cb9bf326397e9ec671e98
        # locked
        >>> score1
        dd83f0f00a8cb9bf326397e9ec671e98
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(2, 7, goal=100)
        >>> score0
        84c396a4a472d6de991124c50ce40777
        # locked
        >>> score1
        38086a887499ac2379964fcc3021b260
        # locked
        >>> start
        1d33628009484489f555bc97b14d09a3
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(8, 3, goal=100)
        >>> score0
        38086a887499ac2379964fcc3021b260
        # locked
        >>> score1
        84c396a4a472d6de991124c50ce40777
        # locked
        >>> start
        84c396a4a472d6de991124c50ce40777
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(4, 3, goal=100)
        >>> score0
        7c1c0620204120caaaf6ad1ff32cd9fb
        # locked
        >>> score1
        2b7291f6c80691d4ca00a3b96ae0cbfb
        # locked
        >>> start
        84c396a4a472d6de991124c50ce40777
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(3, 4, goal=100)
        >>> score0
        2b7291f6c80691d4ca00a3b96ae0cbfb
        # locked
        >>> score1
        7c1c0620204120caaaf6ad1ff32cd9fb
        # locked
        >>> start
        1d33628009484489f555bc97b14d09a3
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}