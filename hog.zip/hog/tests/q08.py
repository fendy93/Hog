test = {
  'names': [
    'q08',
    'q8',
    '8'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(0, 0)
        017e434ed2c462a9fd187c37c7d04ae5
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(70, 50)
        017e434ed2c462a9fd187c37c7d04ae5
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(50, 70)
        84c396a4a472d6de991124c50ce40777
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(32, 4, 5, 4)
        84c396a4a472d6de991124c50ce40777
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(20, 25, 5, 4)
        2b7291f6c80691d4ca00a3b96ae0cbfb
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}