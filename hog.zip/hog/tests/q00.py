test = {
  'names': [
    'q00',
    '0',
    'q0'
  ],
  'points': 0,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> test_dice = make_test_dice(4, 1, 2)
        >>> test_dice()
        2b7291f6c80691d4ca00a3b96ae0cbfb
        # locked
        >>> test_dice() # Second call
        1d33628009484489f555bc97b14d09a3
        # locked
        >>> test_dice() # Third call
        107841aef115c8381060f3293e22eacd
        # locked
        >>> test_dice() # Fourth call
        2b7291f6c80691d4ca00a3b96ae0cbfb
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}