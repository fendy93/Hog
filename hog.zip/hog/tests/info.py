info = {
  'hash_key': '053anr6z2ou5qw45aos9w03fg9tzqt70xeplmipl388yi5tszaepj551kpk6aqlao8x6mezlkyzv1chtkmtvoymphg2v1geiub0nv51ez5ynd31uhemb781m056vif4o',
  'name': 'proj1',
  'params': {
    'doctest': {
      'cache': """
      import hog
      from hog import *
      """
    }
  },
  'src_files': [
    'hog.py'
  ],
  'version': '1.0'
}