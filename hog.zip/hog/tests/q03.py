test = {
  'names': [
    'q03',
    '3',
    'q3'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> select_dice(4, 24) == six_sided
        3c2dddb7a389f362e7a624af70b4f47d
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> select_dice(16, 64) == six_sided
        febd8422a837d675caa423dea0de0007
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> select_dice(0, 0) == six_sided
        3c2dddb7a389f362e7a624af70b4f47d
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> select_dice(50, 80) == six_sided
        febd8422a837d675caa423dea0de0007
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}