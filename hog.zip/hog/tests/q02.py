test = {
  'names': [
    'q02',
    '2',
    'q2'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> take_turn(2, 0,  make_test_dice(4, 6, 1))
        38086a887499ac2379964fcc3021b260
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> take_turn(3, 20, make_test_dice(4, 6, 1))
        1d33628009484489f555bc97b14d09a3
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> take_turn(0, 35)
        7c1c0620204120caaaf6ad1ff32cd9fb
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> take_turn(0, 71)
        8182d1ef0b4ff2c05e2fe3923b9c7920
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> take_turn(0, 7)
        df08707dfc46f5f75dc041d2966bf607
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}